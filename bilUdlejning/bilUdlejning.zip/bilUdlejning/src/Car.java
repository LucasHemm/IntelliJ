public interface Car {

    String getRegistrationNumber();
    String getMake();
    String getModel();
    int getNumberOfDoors();
    int getRegistrationFee();

}
